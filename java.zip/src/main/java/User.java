import java.util.Set;
import java.util.TreeSet;

public class User {
    String name;
    Set<String> skills;
    int exp;

    public User(String name, Set<String> skills, int exp) {
        this.name = name;
        this.skills = new TreeSet<>(skills);
        this.exp = exp;
    }

    @Override
    public String toString() {
        return name + " " + String.join(",", skills) + " " + exp;
    }
}