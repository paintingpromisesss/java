import java.util.*;
import java.util.stream.Collectors;

public class Main {
    static LinkedHashMap<String, User> users = new LinkedHashMap<>();
    static LinkedHashMap<String, Job> jobs = new LinkedHashMap<>();
    static FileService fileService = new FileService("commands.txt");

    public static void main(String[] args) {
        restoreData();

        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();

            if (line.isEmpty()) {
                continue;
            }

            if (line.equals("exit")) {
                System.exit(0);
            }

            handleCommand(line, true);
        }
    }

    static void restoreData() {
        List<String> commands = fileService.readCommands();

        for (String command : commands) {
            if (command.startsWith("user ") || command.startsWith("job ")) {
                handleCommand(command, false);
            }
        }
    }

    static void handleCommand(String line, boolean needSave) {
        if (line.equals("user-list")) {
            printUsers();
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.equals("job-list")) {
            printJobs();
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.equals("history")) {
            printHistory();
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.startsWith("user ")) {
            addUser(line);
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.startsWith("job ")) {
            addJob(line);
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.startsWith("suggest ")) {
            suggestJobs(line.substring(8).trim());
            if (needSave) {
                fileService.saveCommand(line);
            }
            return;
        }

        if (line.startsWith("stat ")) {
            handleStat(line);
            if (needSave) {
                fileService.saveCommand(line);
            }
        }
    }

    static void addUser(String line) {
        String[] parts = line.split(" ");
        if (parts.length < 2) {
            return;
        }

        String name = parts[1];
        if (users.containsKey(name)) {
            return;
        }

        Map<String, String> params = parseParams(parts, 2);
        Set<String> skills = parseSet(params.get("--skills"));
        int exp = parseInt(params.get("--exp"));

        users.put(name, new User(name, skills, exp));
    }

    static void addJob(String line) {
        String[] parts = line.split(" ");
        if (parts.length < 2) {
            return;
        }

        String title = parts[1];
        if (jobs.containsKey(title)) {
            return;
        }

        Map<String, String> params = parseParams(parts, 2);
        String company = params.getOrDefault("--company", "");
        Set<String> tags = parseSet(params.get("--tags"));
        int exp = parseInt(params.get("--exp"));

        jobs.put(title, new Job(title, company, tags, exp));
    }

    static void printUsers() {
        for (User user : users.values()) {
            System.out.println(user);
        }
    }

    static void printJobs() {
        jobs.values().stream()
                .sorted(Comparator.comparing(job -> job.title))
                .forEach(System.out::println);
    }

    static void printHistory() {
        List<String> commands = fileService.readCommands();
        for (String command : commands) {
            System.out.println(command);
        }
    }

    static void suggestJobs(String userName) {
        User user = users.get(userName);
        if (user == null) {
            return;
        }

        jobs.values().stream()
                .filter(job -> getScore(user, job) > 0)
                .sorted((a, b) -> {
                    int scoreCompare = Double.compare(getScore(user, b), getScore(user, a));
                    if (scoreCompare != 0) {
                        return scoreCompare;
                    }
                    return a.title.compareTo(b.title);
                })
                .limit(2)
                .forEach(System.out::println);
    }

    static double getScore(User user, Job job) {
        int matches = 0;

        for (String skill : user.skills) {
            if (job.tags.contains(skill)) {
                matches++;
            }
        }

        if (user.exp < job.exp) {
            return matches / 2.0;
        }

        return matches;
    }

    static void handleStat(String line) {
        String[] parts = line.split(" ");
        if (parts.length < 3) {
            return;
        }

        String type = parts[1];
        int n = parseInt(parts[2]);

        if (type.equals("--exp")) {
            jobs.values().stream()
                    .filter(job -> job.exp >= n)
                    .sorted(Comparator.comparing(job -> job.title))
                    .forEach(System.out::println);
            return;
        }

        if (type.equals("--match")) {
            users.values().stream()
                    .filter(user -> countMatches(user) >= n)
                    .sorted(Comparator.comparing(user -> user.name))
                    .forEach(System.out::println);
            return;
        }

        if (type.equals("--top-skills")) {
            users.values().stream()
                    .flatMap(user -> user.skills.stream())
                    .collect(Collectors.groupingBy(skill -> skill, Collectors.counting()))
                    .entrySet()
                    .stream()
                    .sorted((a, b) -> {
                        int countCompare = Long.compare(b.getValue(), a.getValue());
                        if (countCompare != 0) {
                            return countCompare;
                        }
                        return a.getKey().compareTo(b.getKey());
                    })
                    .limit(n)
                    .map(Map.Entry::getKey)
                    .sorted()
                    .forEach(System.out::println);
        }
    }

    static long countMatches(User user) {
        return jobs.values().stream()
                .filter(job -> getScore(user, job) > 0)
                .count();
    }

    static Map<String, String> parseParams(String[] parts, int start) {
        Map<String, String> result = new HashMap<>();

        for (int i = start; i < parts.length; i++) {
            int pos = parts[i].indexOf('=');
            if (pos == -1) {
                continue;
            }

            String key = parts[i].substring(0, pos);
            String value = parts[i].substring(pos + 1);
            result.put(key, value);
        }

        return result;
    }

    static Set<String> parseSet(String value) {
        Set<String> result = new TreeSet<>();

        if (value == null || value.isEmpty()) {
            return result;
        }

        String[] parts = value.split(",");
        for (String part : parts) {
            String s = part.trim();
            if (!s.isEmpty()) {
                result.add(s);
            }
        }

        return result;
    }

    static int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }
}