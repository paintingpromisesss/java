import java.util.Set;
import java.util.TreeSet;

public class Job {
    String title;
    String company;
    Set<String> tags;
    int exp;

    public Job(String title, String company, Set<String> tags, int exp) {
        this.title = title;
        this.company = company;
        this.tags = new TreeSet<>(tags);
        this.exp = exp;
    }

    @Override
    public String toString() {
        return title + " at " + company;
    }
}